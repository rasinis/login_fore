<?php
$servername = "localhost";
$username = "root"; // Default username for local server
$password = ""; // Default password (leave empty for XAMPP)
$database = "test_data"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$email = $_POST['email'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash password for security

// Insert into database
$sql = "INSERT INTO users (email, password, created_at) VALUES ('$email', '$password', NOW())";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
