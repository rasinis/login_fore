<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>

    <!-- Link to Bootstrap and FontAwesome -->
    <link rel="stylesheet" href="<?= base_url('assets/adminlte/plugins/bootstrap/css/bootstrap.min.css'); ?>">
    <link rel="stylesheet" href="<?= base_url('assets/adminlte/plugins/font-awesome/css/font-awesome.min.css'); ?>">
    <link rel="stylesheet" href="<?= base_url('assets/adminlte/dist/css/adminlte.min.css'); ?>">
    
    <style>
        .navbar .nav-link {
            color: #333;
        }
        .navbar .nav-link:hover {
            color: #007bff;
        }
        .badge {
            position: absolute;
            top: 5px;
            right: 5px;
            font-size: 12px;
        }
    </style>
</head>
<body>

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item"><a class="nav-link" href="#">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="#">Contact</a></li>
        </ul>
    </div>

    <!-- Right-side Icons -->
    <ul class="navbar-nav ml-auto">
        <li class="nav-item">
            <a class="nav-link" href="#"><i class="fa fa-search"></i></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#"><i class="fa fa-comments"></i> <span class="badge badge-danger">3</span></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#"><i class="fa fa-bell"></i> <span class="badge badge-warning">15</span></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#"><i class="fa fa-expand"></i></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#"><i class="fa fa-th"></i></a>
        </li>
    </ul>
</nav>

<!-- Include Bootstrap JS -->
<script src="<?= base_url('assets/adminlte/plugins/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>

</body>
</html>
